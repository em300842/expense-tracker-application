package com.codewithfk.expensetracker.android.utils

object NavRouts {
    const val login="login"
    const val signup="SignUp"
    const val forgotpassword="ForgotPassword"
    const val home="home"
    const val addscreen="AddScreen"
    const val profile="profile"
    const val stats="stats"
}